---
name: tie-tu-hao-generator
description: Generate 贴图号 (WeChat sticker account) cards - 1080x1920 PNG images with cognitive bias/psychology theme. Use when user asks to create 贴图号 content, generate sticker cards, or produce cognitive bias themed images for WeChat publishing. Triggers on: "贴图号", "生成卡片", "思维成长卡片", "认知偏误卡片", "sticker cards".
---

# Tie-Tu-Hao Generator

Generate cognitive bias themed sticker cards for WeChat publishing.

## Quick Start

Run the generation script with card range:

```bash
python3 scripts/generate-cards.py --start 41 --end 50 --theme "认知偏误"
```

## Workflow

1. Generate card content (titles, points, actions, tags)
2. Run Python script to create PNG images
3. Generate HTML cards for preview
4. Generate publish descriptions

## Script Usage

```bash
# Generate PNG images
python3 scripts/generate-cards.py --start 41 --end 50

# Generate HTML cards
python3 scripts/generate-cards.py --start 41 --end 50 --html

# Generate publish descriptions
python3 scripts/generate-cards.py --start 41 --end 50 --publish-text
```

## Content Guidelines

### Theme
Cognitive biases and psychological effects:
- 敌意归因偏误
- 锚定效应
- 幸存者偏差
- 达克效应
- 确认偏误
- 损失厌恶
- 规划谬误
- 从众效应
- 后见之明
- 知行鸿沟

### Card Structure
- Title: "为什么..." question format (20-28 chars)
- 3 key points
- Action item
- 3 hashtags

### Image Specs
- Size: 1080x1920 px
- Format: PNG
- Top gradient bar: 160px
- Title: 52px
- Body: 36px
- Tags: 28px

### Branding
- Bottom text: "🔗 AI工具合集: amosliuster163.github.io/ai-tools-hub"
- Knowledge planet: "成长思维训练营"

## File Organization

Output files go to:
- PNG: `tie-tu-hao/images/card-XX.png`
- HTML: `tie-tu-hao/cards-XX-XX.html`
- Publish text: `tie-tu-hao/cards-XX-XX-publish-text.html`

After publishing, archive to `tie-tu-hao/published/phaseN/`.
