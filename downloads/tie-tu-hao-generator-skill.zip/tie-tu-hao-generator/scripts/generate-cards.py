#!/usr/bin/env python3
"""生成贴图号卡片 - 支持任意期数、主题、引流配置
用法: python3 generate-cards.py --start 41 --end 50 [--theme 认知偏误] [--html] [--publish-text]
"""
from PIL import Image, ImageDraw, ImageFont
import os
import argparse
import json

# 默认卡片数据模板（认知偏误主题）
DEFAULT_CARDS = [
    {
        "title": "为什么你总觉得别人在针对你？",
        "points": [
            "敌意归因偏误：把中性行为解读为恶意",
            "你越认为别人针对你，越容易做出敌对反应",
            "事实是：大多数人根本没时间针对你"
        ],
        "action": "下次觉得被针对时，问自己：还有没有其他解释？",
        "tags": "#敌意归因 #认知偏误 #人际关系",
        "gradient": [(102, 126, 234), (118, 75, 162)]
    },
    {
        "title": "为什么第一个答案总是错的？",
        "points": [
            "锚定效应：第一个信息会锚定你的判断",
            "商家先报高价，再打折，你就觉得赚了",
            "谈判时先出价的人，往往能锚定最终结果"
        ],
        "action": "下次做决定前，主动寻找第2、第3个参考点",
        "tags": "#锚定效应 #决策偏误 #谈判技巧",
        "gradient": [(17, 153, 142), (56, 239, 125)]
    },
    {
        "title": "为什么你总觉得别人比你过得好？",
        "points": [
            "幸存者偏差：你只看到了'幸存'下来的人",
            "社交媒体上晒的都是成功，失败的人沉默了",
            "比较的对象本身就是偏颇的样本"
        ],
        "action": "下次焦虑时提醒自己：我看到的是全部真相吗？",
        "tags": "#幸存者偏差 #社交媒体焦虑 #理性思考",
        "gradient": [(79, 172, 254), (0, 242, 254)]
    },
    {
        "title": "为什么你总是高估自己的能力？",
        "points": [
            "达克效应：能力越低的人越容易高估自己",
            "不知道自己不知道，是最危险的认知状态",
            "真正的高手反而容易自我怀疑"
        ],
        "action": "定期做一次能力自测，找比你强的人给你反馈",
        "tags": "#达克效应 #自我认知 #元认知",
        "gradient": [(250, 112, 154), (254, 225, 64)]
    },
    {
        "title": "为什么你总觉得自己是对的？",
        "points": [
            "确认偏误：人只愿意看到支持自己观点的证据",
            "你搜索'喝咖啡的好处'，搜到的全是好处",
            "真正的理性是主动寻找反驳自己的证据"
        ],
        "action": "下次做决定前，故意搜索反对意见看看",
        "tags": "#确认偏误 #批判性思维 #信息筛选",
        "gradient": [(240, 147, 251), (245, 87, 108)]
    },
    {
        "title": "为什么你总是选择安逸？",
        "points": [
            "损失厌恶：人们对损失的恐惧远大于对收益的渴望",
            "放弃100块的痛苦，是捡到100块快乐的2倍",
            "所以你不愿改变，不是因为现状好，是怕失去"
        ],
        "action": "列出1个你因为怕失去而不敢尝试的事",
        "tags": "#损失厌恶 #行为经济学 #舒适区",
        "gradient": [(161, 140, 209), (251, 194, 235)]
    },
    {
        "title": "为什么你总觉得明天会更好？",
        "points": [
            "规划谬误：人总是低估完成任务所需的时间",
            "你觉得明天能写完的报告，拖了一周还没开始",
            "不是你懒，是你的大脑天生过于乐观"
        ],
        "action": "下次做计划时，把预估时间乘以2.5倍",
        "tags": "#规划谬误 #时间管理 #自我认知",
        "gradient": [(255, 236, 210), (252, 182, 159)]
    },
    {
        "title": "为什么你容易被带节奏？",
        "points": [
            "从众效应：人会无意识地模仿多数人的行为",
            "排队的餐厅不一定好吃，但你会觉得一定好吃",
            "独立思考的第一步是意识到自己在从众"
        ],
        "action": "下次跟风前，问自己：如果只有我一个人，我还会这么做吗？",
        "tags": "#从众效应 #独立思考 #群体心理",
        "gradient": [(102, 126, 234), (118, 75, 162)]
    },
    {
        "title": "为什么你总觉得过去的自己很蠢？",
        "points": [
            "后见之明：事后看什么都觉得'我早该知道'",
            "你已经知道了结果，所以觉得当初的选择很明显",
            "但当时的你，根本没有现在这些信息"
        ],
        "action": "下次别嘲笑过去的自己，当时的你已经做了最好的选择",
        "tags": "#后见之明 #自我宽容 #决策复盘",
        "gradient": [(17, 153, 142), (56, 239, 125)]
    },
    {
        "title": "为什么你知道很多道理，还是过不好？",
        "points": [
            "知行鸿沟：知道和做到之间隔着巨大的鸿沟",
            "你以为你知道了，实际上只是'听说过'",
            "真正的知道=经历过+反思过+实践过"
        ],
        "action": "挑1个你'知道'的道理，今天实践一次",
        "tags": "#知行合一 #实践出真知 #认知升级",
        "gradient": [(79, 172, 254), (0, 242, 254)]
    }
]

# 配置
CONFIG = {
    "output_dir": "/Users/amosliu/.openclaw/workspace-xiaomo/tie-tu-hao/images",
    "html_dir": "/Users/amosliu/.openclaw/workspace-xiaomo/tie-tu-hao",
    "ai_tools_hub": "amosliuster163.github.io/ai-tools-hub",
    "knowledge_planet": "成长思维训练营",
    "bottom_text": "🔗 AI工具合集: amosliuster163.github.io/ai-tools-hub",
    "top_label": "🔥 思维成长训练营·精华卡片"
}

# 字体路径
FONT_PATHS = [
    "/System/Library/Fonts/PingFang.ttc",
    "/System/Library/Fonts/STHeiti Medium.ttc",
    "/System/Library/Fonts/AppleSDGothicNeo.ttc",
]

def load_fonts():
    """加载中文字体"""
    title_font = None
    body_font = None
    small_font = None
    
    for fp in FONT_PATHS:
        if os.path.exists(fp):
            try:
                title_font = ImageFont.truetype(fp, 52)
                body_font = ImageFont.truetype(fp, 36)
                small_font = ImageFont.truetype(fp, 28)
                print(f"使用字体：{fp}")
                break
            except:
                continue
    
    if title_font is None:
        print("⚠️ 未找到中文字体，使用默认字体")
        title_font = ImageFont.load_default()
        body_font = ImageFont.load_default()
        small_font = ImageFont.load_default()
    
    return title_font, body_font, small_font

def generate_png(cards, start_num, output_dir):
    """生成PNG图片"""
    os.makedirs(output_dir, exist_ok=True)
    title_font, body_font, small_font = load_fonts()
    
    for i, card in enumerate(cards):
        card_num = start_num + i
        print(f"生成卡片 {card_num}: {card['title'][:20]}...")
        
        img = Image.new('RGB', (1080, 1920), '#ffffff')
        draw = ImageDraw.Draw(img)
        
        # 顶部渐变条
        c1 = tuple(card['gradient'][0])
        c2 = tuple(card['gradient'][1])
        for y in range(160):
            r = int(c1[0] + (c2[0] - c1[0]) * y / 160)
            g = int(c1[1] + (c2[1] - c1[1]) * y / 160)
            b = int(c1[2] + (c2[2] - c1[2]) * y / 160)
            draw.line([(0, y), (1080, y)], fill=(r, g, b))
        
        # 顶部标签文字
        draw.text((540, 50), CONFIG["top_label"], fill='#ffffff', font=small_font, anchor="mm")
        
        # 标题
        draw.text((540, 260), card['title'], fill='#1a1a1a', font=title_font, anchor="mm")
        
        # 分隔线
        line_y = 380
        draw.line([(140, line_y), (940, line_y)], fill=c1, width=4)
        
        # 要点
        y_offset = 460
        for j, point in enumerate(card['points']):
            draw.text((80, y_offset), f"💡 要点{j+1}：", fill=c1[0], font=body_font)
            bbox = draw.textbbox((80, y_offset), f"💡 要点{j+1}：", font=body_font)
            text_x = bbox[2] + 20
            draw.text((text_x, y_offset), point, fill='#444444', font=body_font)
            y_offset += 80
        
        # 行动框
        box_y = y_offset + 60
        draw.rounded_rectangle([(80, box_y), (1000, box_y + 200)], radius=20, fill='#f8f9fa', outline=c1, width=4)
        draw.text((120, box_y + 30), "🎯 今天行动：", fill=c1[0], font=body_font)
        draw.text((120, box_y + 100), card['action'], fill='#444444', font=body_font)
        
        # 标签
        draw.text((540, 1780), card['tags'], fill='#999999', font=small_font, anchor="mm")
        
        # 底部品牌
        draw.text((540, 1850), CONFIG["bottom_text"], fill='#cccccc', font=small_font, anchor="mm")
        
        # 保存图片
        filename = f"card-{card_num:02d}.png"
        filepath = os.path.join(output_dir, filename)
        img.save(filepath, "PNG")
        print(f"  已保存：{filepath}")
    
    print(f"\n✅ 全部完成！共生成{len(cards)}张卡片")

def generate_html(cards, start_num, html_dir):
    """生成HTML卡片"""
    html_content = """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0; padding:0; background:#f5f5f5;">
"""
    
    for i, card in enumerate(cards):
        card_num = start_num + i
        html_content += f"""
<!-- card-{card_num}: {card['title'][:10]} -->
<table width="100%" cellpadding="0" cellspacing="0" style="max-width:600px; margin:20px auto; background:#ffffff; border-radius:12px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,0.1);">
  <tr>
    <td style="padding:30px;">
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td style="background:linear-gradient(135deg,rgb({card['gradient'][0][0]},{card['gradient'][0][1]},{card['gradient'][0][2]}) 0%,rgb({card['gradient'][1][0]},{card['gradient'][1][1]},{card['gradient'][1][2]}) 100%); color:#ffffff; padding:12px 16px; border-radius:8px; font-size:14px; font-weight:bold; text-align:center;">
            🔥 思维成长训练营·精华卡片
          </td>
        </tr>
      </table>
      <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:24px;">
        <tr>
          <td style="font-size:24px; font-weight:bold; color:#333333; padding-bottom:16px; border-bottom:2px solid #667eea;">
            {card['title']}
          </td>
        </tr>
        <tr>
          <td style="padding-top:20px; font-size:16px; line-height:1.8; color:#555555;">
            {''.join([f'<p style="margin:0 0 12px 0;">{p}</p>' for p in card['points']])}
          </td>
        </tr>
        <tr>
          <td style="padding-top:20px; background:#f0faff; padding:16px; border-radius:8px; border-left:4px solid #667eea;">
            <p style="margin:0; font-size:16px; font-weight:bold; color:#333333;">
              🎯 今天行动：
            </p>
            <p style="margin:8px 0 0 0; font-size:15px; color:#555555;">
              {card['action']}
            </p>
          </td>
        </tr>
        <tr>
          <td style="padding-top:16px; font-size:12px; color:#999999; text-align:center;">
            {card['tags']}
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
"""
    
    html_content += """
</body>
</html>
"""
    
    filename = f"cards-{start_num:02d}-{start_num + len(cards) - 1:02d}.html"
    filepath = os.path.join(html_dir, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(html_content)
    print(f"✅ 已生成HTML：{filename}")

def generate_publish_text(cards, start_num, html_dir):
    """生成发布描述"""
    html_content = """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
</head>
<body style="margin:0; padding:20px; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
"""
    
    for i, card in enumerate(cards):
        card_num = start_num + i
        is_last = (i == len(cards) - 1)
        
        # 引流话术
        if is_last:
            drive_text = f"🔗 AI工具合集：{CONFIG['ai_tools_hub']} | 知识星球搜「{CONFIG['knowledge_planet']}」"
        else:
            drive_text = f"🔗 AI工具合集：{CONFIG['ai_tools_hub']}"
        
        html_content += f"""
<!-- card-{card_num} -->
<table width="100%" cellpadding="0" cellspacing="0" style="max-width:600px; margin:0 auto 20px; background:#fff; border-radius:8px; box-shadow:0 1px 4px rgba(0,0,0,0.1);">
<tr><td style="padding:16px;">
<p style="font-size:18px; font-weight:bold; color:#333; margin:0 0 8px;">{card['title']}</p>
<p style="font-size:14px; color:#666; margin:0 0 8px;">{card['points'][0]}</p>
<p style="font-size:12px; color:#667eea; margin:0 0 8px;">{drive_text}</p>
<p style="font-size:13px; color:#999; margin:0;">{card['tags']}</p>
</td></tr>
</table>
"""
    
    html_content += """
</body>
</html>
"""
    
    filename = f"cards-{start_num:02d}-{start_num + len(cards) - 1:02d}-publish-text.html"
    filepath = os.path.join(html_dir, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(html_content)
    print(f"✅ 已生成发布描述：{filename}")

def main():
    parser = argparse.ArgumentParser(description='生成贴图号卡片')
    parser.add_argument('--start', type=int, default=41, help='起始卡片编号')
    parser.add_argument('--end', type=int, default=50, help='结束卡片编号')
    parser.add_argument('--theme', type=str, default='认知偏误', help='主题名称')
    parser.add_argument('--html', action='store_true', help='生成HTML卡片')
    parser.add_argument('--publish-text', action='store_true', help='生成发布描述')
    parser.add_argument('--cards-json', type=str, help='自定义卡片数据JSON文件路径')
    
    args = parser.parse_args()
    
    # 加载卡片数据
    cards = DEFAULT_CARDS[:args.end - args.start + 1]
    if args.cards_json:
        with open(args.cards_json, 'r', encoding='utf-8') as f:
            cards = json.load(f)
    
    print(f"🎨 开始生成贴图号卡片")
    print(f"   主题：{args.theme}")
    print(f"   范围：card-{args.start} ~ card-{args.end}")
    print(f"   数量：{len(cards)}张")
    
    # 生成PNG
    generate_png(cards, args.start, CONFIG["output_dir"])
    
    # 生成HTML
    if args.html:
        generate_html(cards, args.start, CONFIG["html_dir"])
    
    # 生成发布描述
    if args.publish_text:
        generate_publish_text(cards, args.start, CONFIG["html_dir"])
    
    print("\n🎉 全部完成！")

if __name__ == '__main__':
    main()
