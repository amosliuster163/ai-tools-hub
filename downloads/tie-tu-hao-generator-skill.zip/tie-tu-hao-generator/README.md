# 贴图号卡片生成器（OpenClaw Skill版）

> 一键生成微信贴图号卡片，1080x1920竖版PNG图片 + HTML预览 + 发布描述

---

## 功能特点

- **认知偏误/思维模型主题**：复杂心理学概念，用"为什么..."式提问表达
- **一键生成**：10张卡片批量输出（PNG + HTML + 发布描述）
- **内置引流**：自动添加AI Tools Hub网址
- **OpenClaw集成**：通过Skill自动触发，与小墨工作流无缝衔接

---

## 安装

```bash
# 1. 解压到OpenClaw skills目录
unzip tie-tu-hao-generator-skill.zip -d ~/.openclaw/skills/

# 2. 安装Python依赖
pip3 install Pillow
```

---

## 使用

### 快速生成

```bash
python3 scripts/generate-cards.py --start 41 --end 50 --theme "认知偏误"
```

### 仅生成图片

```bash
python3 scripts/generate-cards.py --start 41 --end 50
```

### 生成HTML预览

```bash
python3 scripts/generate-cards.py --start 41 --end 50 --html
```

### 生成发布描述

```bash
python3 scripts/generate-cards.py --start 41 --end 50 --publish-text
```

---

## 输出文件

```
tie-tu-hao/
├── images/
│   ├── card-41.png
│   ├── card-42.png
│   └── ...（共10张）
├── cards-41-50.html          # HTML预览
└── cards-41-50-publish-text.html  # 发布描述
```

---

## 卡片格式

- **尺寸**：1080x1920 px（竖版）
- **格式**：PNG
- **风格**：渐变顶部 + 大字报 + 行动建议
- **引流**：底部含"🔗 AI工具合集: amosliuster163.github.io/ai-tools-hub"

---

## 自定义主题

修改 `generate-cards.py` 中的 `DEFAULT_CARDS` 数组，或传入自定义JSON文件。

---

## 依赖

- OpenClaw环境
- Python 3.9+
- Pillow (`pip3 install Pillow`)

---

## 作者

小墨（OpenClaw内容创作Agent）

## 许可证

MIT
