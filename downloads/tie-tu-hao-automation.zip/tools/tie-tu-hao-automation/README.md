# 贴图号自动生成工具（独立版）

> 不依赖OpenClaw，独立命令行工具，支持百炼/DeepSeek/MiniMax API，一键生成微信贴图号卡片

---

## 功能特点

- **AI自动选题**：调用大模型API生成认知偏误主题文案
- **多API支持**：百炼、DeepSeek、MiniMax，随时切换
- **零成本**：用自有API，不额外花钱
- **可移植**：任何Python环境都能跑，打包即走
- **完整输出**：PNG图片 + HTML卡片 + 发布描述

---

## 安装

```bash
# 1. 下载并解压项目
unzip tie-tu-hao-automation.zip
cd tie-tu-hao-automation

# 2. 安装依赖
pip3 install -r requirements.txt
```

---

## 第一步：申请API Key（三选一）

### 选项1：百炼（推荐，性价比高）

1. 访问 [阿里云百炼平台](https://bailian.console.aliyun.com/)
2. 用阿里云账号登录（没有就注册一个）
3. 进入"API-KEY管理"页面
4. 点击"创建新的API-KEY"
5. 复制生成的Key（格式：`sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`）

**免费额度**：新用户有免费额度，用完后按量计费（很便宜）

### 选项2：DeepSeek

1. 访问 [DeepSeek开放平台](https://platform.deepseek.com/)
2. 注册并登录
3. 进入"API Keys"页面
4. 创建新的API Key

### 选项3：MiniMax

1. 访问 [MiniMax开放平台](https://api.minimax.chat/)
2. 注册并登录
3. 创建API Key

---

## 第二步：配置API Key

编辑 `config.yaml` 文件：

```yaml
api:
  provider: "bailian"  # 改成你用的：bailian / deepseek / minimax
  keys:
    bailian:
      api_key: "sk-你的百炼API密钥"  # ← 替换成你申请的Key
      base_url: "https://dashscope.aliyuncs.com/compatible-mode/v1"
      model: "qwen3.6-plus"
    deepseek:
      api_key: "sk-你的DeepSeek密钥"  # ← 如果用DeepSeek，填这里
      base_url: "https://api.deepseek.com/v1"
      model: "deepseek-chat"
    minimax:
      api_key: "你的MiniMax密钥"  # ← 如果用MiniMax，填这里
      base_url: "https://api.minimax.chat/v1"
      model: "MiniMax-Text-01"
```

**只需要改两个地方**：
1. `provider` 改成你用的平台
2. 对应的 `api_key` 填进去

---

## 使用

### 生成新内容（AI自动选题）

```bash
python3 main.py --start 41 --end 50 --theme "认知偏误"
```

### 跳过AI，用本地JSON

```bash
python3 main.py --start 41 --end 50 --json cards.json
```

---

## 输出文件

```
output/
├── images/
│   ├── card-41.png
│   ├── card-42.png
│   └── ...（共10张）
├── cards-41-50.html
└── cards-41-50-publish-text.html
```

---

## 卡片格式

- **尺寸**：1080x1920 px（竖版，适合微信）
- **格式**：PNG
- **风格**：渐变顶部 + 大字报 + 行动建议
- **引流**：底部自动含AI Tools Hub网址

---

## 依赖

- Python 3.9+
- Pillow
- openai SDK
- PyYAML

```bash
pip3 install pillow openai pyyaml
```

---

## 常见问题

### Q: 报错 "invalid_api_key" 怎么办？
A: 检查API Key是否正确复制，有没有多余空格。百炼的Key格式是 `sk-` 开头。

### Q: 可以同时用多个API吗？
A: 可以。在config.yaml里填好所有Key，改 `provider` 就能切换。

### Q: 生成图片失败怎么办？
A: 确认已安装Pillow：`pip3 install pillow`

### Q: 如何自定义主题？
A: 修改 `--theme` 参数，例如 `--theme "职场心理学"`

---

## 作者

小墨（OpenClaw内容创作Agent）

## 许可证

MIT
