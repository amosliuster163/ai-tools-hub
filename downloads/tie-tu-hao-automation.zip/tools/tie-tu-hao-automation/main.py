#!/usr/bin/env python3
"""
贴图号自动化工具 - 主程序
用法: python main.py --start 41 --end 50 --theme "认知偏误"
"""
import argparse
import json
import os
import yaml
from content_generator import generate_cards
from image_generator import generate_images
from html_generator import generate_html, generate_publish_text

def main():
    parser = argparse.ArgumentParser(description='贴图号自动生成工具')
    parser.add_argument('--start', type=int, default=41, help='起始卡片编号')
    parser.add_argument('--end', type=int, default=50, help='结束卡片编号')
    parser.add_argument('--theme', type=str, default='认知偏误', help='主题')
    parser.add_argument('--api', type=str, choices=['bailian', 'deepseek', 'minimax'], help='API提供商')
    parser.add_argument('--config', type=str, default='config.yaml', help='配置文件路径')
    parser.add_argument('--skip-ai', action='store_true', help='跳过AI生成，使用已有cards.json')
    
    args = parser.parse_args()
    
    count = args.end - args.start + 1
    print(f"🎯 贴图号自动生成工具")
    print(f"   主题：{args.theme}")
    print(f"   范围：card-{args.start} ~ card-{args.end}")
    print(f"   数量：{count}张")
    print()
    
    # 读取配置
    with open(args.config, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    
    # 覆盖API配置
    if args.api:
        config['api']['provider'] = args.api
    
    # 输出目录
    images_dir = config['output']['images_dir']
    html_dir = config['output']['html_dir']
    os.makedirs(images_dir, exist_ok=True)
    os.makedirs(html_dir, exist_ok=True)
    
    # Step 1: 生成内容
    if not args.skip_ai:
        print("📝 第一步：AI生成卡片文案...")
        cards = generate_cards(count, args.theme, args.config)
        if cards is None:
            print("❌ 内容生成失败，退出")
            return
        
        cards_file = "cards.json"
        with open(cards_file, 'w', encoding='utf-8') as f:
            json.dump(cards, f, ensure_ascii=False, indent=2)
        print(f"💾 文案已保存到 {cards_file}")
    else:
        cards_file = "cards.json"
        if not os.path.exists(cards_file):
            print(f"❌ 找不到{cards_file}，请先运行AI生成或手动创建")
            return
        with open(cards_file, 'r', encoding='utf-8') as f:
            cards = json.load(f)
        print("📂 使用已有文案：cards.json")
    
    print()
    
    # Step 2: 生成图片
    print("🎨 第二步：生成PNG图片...")
    generate_images(cards, args.start, images_dir, config)
    print()
    
    # Step 3: 生成HTML
    print("📄 第三步：生成HTML卡片...")
    generate_html(cards, args.start, html_dir, config)
    print()
    
    # Step 4: 生成发布描述
    print("📝 第四步：生成发布描述...")
    generate_publish_text(cards, args.start, html_dir, config)
    print()
    
    # 完成报告
    print("=" * 50)
    print("🎉 全部完成！")
    print("=" * 50)
    print(f"📁 图片目录：{os.path.abspath(images_dir)}")
    print(f"📁 HTML目录：{os.path.abspath(html_dir)}")
    print(f"📄 卡片文件：cards-{args.start:02d}-{args.end:02d}.html")
    print(f"📄 发布描述：cards-{args.start:02d}-{args.end:02d}-publish-text.html")
    print()
    print("下一步：")
    print("1. 审核内容（检查错别字、格式）")
    print("2. 手动发布到微信后台")
    print("3. 归档到published/phaseN/")

if __name__ == '__main__':
    main()
