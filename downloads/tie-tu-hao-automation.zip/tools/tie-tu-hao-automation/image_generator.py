#!/usr/bin/env python3
"""生成贴图号卡片PNG图片"""
from PIL import Image, ImageDraw, ImageFont
import os
import json

# 字体路径
FONT_PATHS = [
    "/System/Library/Fonts/PingFang.ttc",
    "/System/Library/Fonts/STHeiti Medium.ttc",
    "/System/Library/Fonts/AppleSDGothicNeo.ttc",
]

def load_fonts():
    title_font = None
    body_font = None
    small_font = None
    
    for fp in FONT_PATHS:
        if os.path.exists(fp):
            try:
                title_font = ImageFont.truetype(fp, 52)
                body_font = ImageFont.truetype(fp, 36)
                small_font = ImageFont.truetype(fp, 28)
                print(f"使用字体：{fp}")
                break
            except:
                continue
    
    if title_font is None:
        print("⚠️ 未找到中文字体，使用默认字体")
        title_font = ImageFont.load_default()
        body_font = ImageFont.load_default()
        small_font = ImageFont.load_default()
    
    return title_font, body_font, small_font

def generate_card_image(card, card_num, output_dir, config):
    title_font, body_font, small_font = load_fonts()
    
    img = Image.new('RGB', (1080, 1920), '#ffffff')
    draw = ImageDraw.Draw(img)
    
    c1 = tuple(card['gradient'][0])
    c2 = tuple(card['gradient'][1])
    
    # 顶部渐变条
    for y in range(160):
        r = int(c1[0] + (c2[0] - c1[0]) * y / 160)
        g = int(c1[1] + (c2[1] - c1[1]) * y / 160)
        b = int(c1[2] + (c2[2] - c1[2]) * y / 160)
        draw.line([(0, y), (1080, y)], fill=(r, g, b))
    
    # 顶部标签
    draw.text((540, 50), "🔥 思维成长训练营·精华卡片", fill='#ffffff', font=small_font, anchor="mm")
    
    # 标题
    draw.text((540, 260), card['title'], fill='#1a1a1a', font=title_font, anchor="mm")
    
    # 分隔线
    draw.line([(140, 380), (940, 380)], fill=c1, width=4)
    
    # 要点
    y_offset = 460
    for i, point in enumerate(card['points']):
        draw.text((80, y_offset), f"💡 要点{i+1}：", fill=c1[0], font=body_font)
        bbox = draw.textbbox((80, y_offset), f"💡 要点{i+1}：", font=body_font)
        text_x = bbox[2] + 20
        draw.text((text_x, y_offset), point, fill='#444444', font=body_font)
        y_offset += 80
    
    # 行动框
    box_y = y_offset + 60
    draw.rounded_rectangle([(80, box_y), (1000, box_y + 200)], radius=20, fill='#f8f9fa', outline=c1, width=4)
    draw.text((120, box_y + 30), "🎯 今天行动：", fill=c1[0], font=body_font)
    draw.text((120, box_y + 100), card['action'], fill='#444444', font=body_font)
    
    # 标签
    draw.text((540, 1780), card['tags'], fill='#999999', font=small_font, anchor="mm")
    
    # 底部品牌
    draw.text((540, 1850), config['branding']['bottom_text'], fill='#cccccc', font=small_font, anchor="mm")
    
    # 保存
    os.makedirs(output_dir, exist_ok=True)
    filename = f"card-{card_num:02d}.png"
    filepath = os.path.join(output_dir, filename)
    img.save(filepath, "PNG")
    return filepath

def generate_images(cards, start_num, output_dir, config):
    paths = []
    for i, card in enumerate(cards):
        card_num = start_num + i
        print(f"🎨 生成卡片 {card_num}: {card['title'][:20]}...")
        filepath = generate_card_image(card, card_num, output_dir, config)
        paths.append(filepath)
        print(f"  ✅ {filepath}")
    
    print(f"\n✅ 全部完成！共生成{len(cards)}张图片")
    return paths

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=str, required=True, help='cards.json路径')
    parser.add_argument('--start', type=int, required=True, help='起始卡片编号')
    parser.add_argument('--output', type=str, default='./output/images', help='输出目录')
    parser.add_argument('--config', type=str, default='config.yaml')
    
    args = parser.parse_args()
    
    with open(args.input, 'r', encoding='utf-8') as f:
        cards = json.load(f)
    
    import yaml
    with open(args.config, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    
    generate_images(cards, args.start, args.output, config)
