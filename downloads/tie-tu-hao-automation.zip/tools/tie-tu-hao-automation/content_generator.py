#!/usr/bin/env python3
"""通过OpenAI兼容API生成卡片文案"""
import openai
import json
import yaml

GRADIENTS = [
    [(102, 126, 234), (118, 75, 162)],  # 紫蓝
    [(17, 153, 142), (56, 239, 125)],   # 绿青
    [(79, 172, 254), (0, 242, 254)],    # 蓝青
    [(250, 112, 154), (254, 225, 64)],  # 粉黄
    [(240, 147, 251), (245, 87, 108)],  # 粉紫
    [(161, 140, 209), (251, 194, 235)], # 紫粉
    [(255, 236, 210), (252, 182, 159)], # 橙黄
]

SYSTEM_PROMPT = """你是认知心理学专家，擅长把复杂的认知偏误用简单有趣的"为什么..."提问方式表达。
请生成{count}张卡片内容，每张包含：
- title: "为什么..."式提问（20-28字）
- points: 3个要点（每个20-30字，口语化，不说教）
- action: 一个具体可执行的行动建议（15-25字）
- tags: 3个相关标签（#格式）
- gradient_index: 0-6之间的整数（代表渐变色）

主题：{theme}
要求：
1. 标题要吸引眼球，用"为什么"开头
2. 要点要反常识，让人有"原来如此"的感觉
3. 行动建议要具体可执行，不要空话
4. 每张卡片主题不能重复

只返回JSON数组，不要其他文字。格式示例：
[
  {{
    "title": "为什么...",
    "points": ["...", "...", "..."],
    "action": "...",
    "tags": "#... #... #...",
    "gradient_index": 0
  }}
]
"""

def load_config(config_path="config.yaml"):
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def generate_cards(count, theme, config_path="config.yaml"):
    config = load_config(config_path)
    api_config = config['api']
    provider = api_config['provider']
    keys = api_config['keys'][provider]
    
    client = openai.OpenAI(
        api_key=keys['api_key'],
        base_url=keys['base_url']
    )
    
    prompt = SYSTEM_PROMPT.format(count=count, theme=theme)
    
    print(f"🤖 调用API：{provider} ({keys['model']})")
    print(f"📝 主题：{theme}")
    print(f"🔢 数量：{count}张")
    
    response = client.chat.completions.create(
        model=keys['model'],
        messages=[
            {"role": "system", "content": "你是认知心理学专家。"},
            {"role": "user", "content": prompt}
        ],
        temperature=0.8,
        max_tokens=3000,
        timeout=60
    )
    
    content = response.choices[0].message.content
    
    # 解析JSON
    try:
        # 尝试直接解析
        cards = json.loads(content)
    except json.JSONDecodeError:
        # 如果包含markdown代码块，提取内容
        if "```json" in content:
            json_str = content.split("```json")[1].split("```")[0].strip()
            cards = json.loads(json_str)
        else:
            print("❌ API返回格式异常")
            print(f"返回内容：{content[:200]}...")
            return None
    
    # 添加渐变色
    for card in cards:
        idx = card.get('gradient_index', 0) % len(GRADIENTS)
        card['gradient'] = GRADIENTS[idx]
        del card['gradient_index']
    
    print(f"✅ 生成成功！共{len(cards)}张卡片")
    return cards

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--count', type=int, default=10)
    parser.add_argument('--theme', type=str, default='认知偏误')
    parser.add_argument('--config', type=str, default='config.yaml')
    parser.add_argument('--output', type=str, default='cards.json')
    
    args = parser.parse_args()
    
    cards = generate_cards(args.count, args.theme, args.config)
    
    if cards:
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(cards, f, ensure_ascii=False, indent=2)
        print(f"💾 已保存到 {args.output}")
