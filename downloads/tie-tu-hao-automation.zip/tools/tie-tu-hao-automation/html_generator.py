#!/usr/bin/env python3
"""生成HTML卡片和发布描述"""
import json
import os

def generate_html(cards, start_num, output_dir, config):
    html = """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0; padding:0; background:#f5f5f5;">
"""
    
    for i, card in enumerate(cards):
        card_num = start_num + i
        c1 = tuple(card['gradient'][0])
        c2 = tuple(card['gradient'][1])
        
        html += f"""
<!-- card-{card_num}: {card['title'][:10]} -->
<table width="100%" cellpadding="0" cellspacing="0" style="max-width:600px; margin:20px auto; background:#ffffff; border-radius:12px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,0.1);">
  <tr>
    <td style="padding:30px;">
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td style="background:linear-gradient(135deg,rgb({c1[0]},{c1[1]},{c1[2]}) 0%,rgb({c2[0]},{c2[1]},{c2[2]}) 100%); color:#ffffff; padding:12px 16px; border-radius:8px; font-size:14px; font-weight:bold; text-align:center;">
            🔥 思维成长训练营·精华卡片
          </td>
        </tr>
      </table>
      <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:24px;">
        <tr>
          <td style="font-size:24px; font-weight:bold; color:#333333; padding-bottom:16px; border-bottom:2px solid #667eea;">
            {card['title']}
          </td>
        </tr>
        <tr>
          <td style="padding-top:20px; font-size:16px; line-height:1.8; color:#555555;">
            {''.join([f'<p style="margin:0 0 12px 0;">{p}</p>' for p in card['points']])}
          </td>
        </tr>
        <tr>
          <td style="padding-top:20px; background:#f0faff; padding:16px; border-radius:8px; border-left:4px solid #667eea;">
            <p style="margin:0; font-size:16px; font-weight:bold; color:#333333;">
              🎯 今天行动：
            </p>
            <p style="margin:8px 0 0 0; font-size:15px; color:#555555;">
              {card['action']}
            </p>
          </td>
        </tr>
        <tr>
          <td style="padding-top:16px; font-size:12px; color:#999999; text-align:center;">
            {card['tags']}
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
"""
    
    html += """
</body>
</html>
"""
    
    os.makedirs(output_dir, exist_ok=True)
    filename = f"cards-{start_num:02d}-{start_num + len(cards) - 1:02d}.html"
    filepath = os.path.join(output_dir, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(html)
    print(f"✅ 已生成HTML：{filename}")
    return filepath

def generate_publish_text(cards, start_num, output_dir, config):
    html = """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
</head>
<body style="margin:0; padding:20px; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
"""
    
    branding = config['branding']
    ai_hub = branding['ai_tools_hub']
    planet = branding['knowledge_planet']
    
    for i, card in enumerate(cards):
        card_num = start_num + i
        is_last = (i == len(cards) - 1)
        
        if is_last:
            drive_text = f"🔗 AI工具合集：{ai_hub} | 知识星球搜「{planet}」"
        else:
            drive_text = f"🔗 AI工具合集：{ai_hub}"
        
        html += f"""
<!-- card-{card_num} -->
<table width="100%" cellpadding="0" cellspacing="0" style="max-width:600px; margin:0 auto 20px; background:#fff; border-radius:8px; box-shadow:0 1px 4px rgba(0,0,0,0.1);">
<tr><td style="padding:16px;">
<p style="font-size:18px; font-weight:bold; color:#333; margin:0 0 8px;">{card['title']}</p>
<p style="font-size:14px; color:#666; margin:0 0 8px;">{card['points'][0]}</p>
<p style="font-size:12px; color:#667eea; margin:0 0 8px;">{drive_text}</p>
<p style="font-size:13px; color:#999; margin:0;">{card['tags']}</p>
</td></tr>
</table>
"""
    
    html += """
</body>
</html>
"""
    
    os.makedirs(output_dir, exist_ok=True)
    filename = f"cards-{start_num:02d}-{start_num + len(cards) - 1:02d}-publish-text.html"
    filepath = os.path.join(output_dir, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(html)
    print(f"✅ 已生成发布描述：{filename}")
    return filepath

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=str, required=True, help='cards.json路径')
    parser.add_argument('--start', type=int, required=True, help='起始卡片编号')
    parser.add_argument('--output', type=str, default='./output', help='输出目录')
    parser.add_argument('--config', type=str, default='config.yaml')
    parser.add_argument('--type', type=str, choices=['html', 'publish', 'all'], default='all')
    
    args = parser.parse_args()
    
    with open(args.input, 'r', encoding='utf-8') as f:
        cards = json.load(f)
    
    import yaml
    with open(args.config, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)
    
    if args.type in ['html', 'all']:
        generate_html(cards, args.start, args.output, config)
    
    if args.type in ['publish', 'all']:
        generate_publish_text(cards, args.start, args.output, config)
